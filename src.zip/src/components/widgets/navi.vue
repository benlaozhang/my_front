<template>
    <div class="main">
        <el-menu
            :default-active="1"
            class="el-menu-demo"
            mode="horizontal"
            @select="handleSelect"
            text-color="#FFFFFF"
            background-color="#A9A9A9"
            active-text-color="#FF7F50">

            <el-menu-item index="1"><a href="/">I&D</a></el-menu-item>
            <el-menu-item index="2"><a href="">Assurance</a></el-menu-item>
            <el-menu-item index="3"><a href="">R&Q</a></el-menu-item>
            <el-menu-item index="4"><a href="">GTS</a></el-menu-item>
        </el-menu>
    </div>
</template>


<script>
    export default {
        name:"navigator",
        data() {
        return {
            activeIndex: '1',
        };
        },
        methods: {
        handleSelect(key, keyPath) {
            console.log(key, keyPath);
        }
        }
    }
</script>

<style scoped>
    .el-menu-item{
        display: inline-block;
        margin-right: 20px;
    }
    .el-menu-item.a{
        font-family: 'Courier New', Courier, monospace;
        font-size: 100%;
    }
</style>
