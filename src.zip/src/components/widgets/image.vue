<template>
    <el-container>
        <el-carousel indicator-position="outside" height="400px" style="width:500px;">
            <el-carousel-item v-for="item in imageList" :key="item.name">
                <img :src="item.src" style="height:100%;width:100%;" alt="图片丢失了" :title="item.title">   
            </el-carousel-item>
        </el-carousel>
        <div></div>
    </el-container>
</template>

<script>
export default {
    name:"image",
    data(){
        return {
            imageList:[{
                name: "png1",
                src: require("@/assets/image-list/1.png"),
                title: "这是1.png",
            },
            {
                name: "png2",
                src: require("@/assets/image-list/2.png"),
                title: "这是2.png",
            },
            {
                name: "png3",
                src: require("@/assets/image-list/3.png"),
                title: "这是3.png",
            }]
        }
    }
}
</script>