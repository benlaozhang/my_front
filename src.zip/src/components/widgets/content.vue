<template>
    <ul class="infinite-list" v-infinite-scroll="load" style="overflow:auto">
        <li v-for="i in count" :key=i class="infinite-list-item">{{ i }}</li>
    </ul>
</template>

<script>
    export default {
        name:"content",
        data () {
        return {
            count: 0
        }
        },
        methods: {
        load () {
            this.count += 2
        }
        }
    }
</script>