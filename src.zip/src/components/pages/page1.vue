<template>
    <el-container>
        <!-- 页头 -->
        <el-header>
            <el-container>
                <div class="logo"></div>
                <div class="site-name">I&D Digital Assets</div>
                
                <nel-dropdow trigger="click">
                    <span class="el-dropdown-link" style="line-height: 90px;">
                        <el-avatar icon="el-icon-user-solid"></el-avatar>
                    </span>
                    <el-dropdown-menu slot="dropdown">
                        <el-dropdown-item>
                            <div>
                                <span>user</span>
                            </div>
                        </el-dropdown-item>
                        <el-dropdown-item>
                            <div>
                                <span>email</span>
                            </div>
                        </el-dropdown-item>
                        <el-dropdown-item>
                            <div>
                                <span>grade</span>
                            </div>
                        </el-dropdown-item>
                    </el-dropdown-menu>
                </nel-dropdow>
            </el-container>
        </el-header>
        <div><navi></navi></div>
        <!-- 页面内容 -->
        <el-aside style="width:600px"><im></im></el-aside>
        <el-main></el-main>
        <!-- 页脚 -->
        <el-footer height="38.8px">
            <span class="footer-info"> 
                Innovation & Digital
            </span>
            <span class="footer-info">
                SDC 数字化解决方案专业团队
            </span>
            <span class="footer-info"> 
                公共邮箱：cn.sdc.innovation@cn.pwc.com
            </span>
            <span class="footer-info">
                常用链接：
                <a href="http://10.158.14.78:9527/home/index" type="primary">I&D Service Desk</a>
            </span>
            <span class="footer-info">
                <a href="http://cnshaappuwv061:8000/#/views/IDProjectTrackingDashboard/Home">I&D Dashboard</a>
            </span>
        </el-footer>
    </el-container>
</template>

<script>
    import im from "@/components/widgets/image"
    import navi from '@/components/widgets/navi'
    import cont from '@/components/widgets/content'

    export default {
    name: 'page1',
    components:{
        im,
        navi,
        cont,
    }
}
</script>

<style scoped>
    #app {
        height:100%;
        margin: 0px;
        padding: 0px;
    }

    .el-container {
    height: 100%;
    }

    .el-header {
    background-color: #fff;
    color: #333;
    text-align: center;
    line-height: 65px;
    padding: 0px;
}

.el-footer {
    background-color: #6d6e71;
    color: #fff;
    font-size: 0.75rem;
    text-align: left;
    }

    .el-main {
    background-color: #F2F2F2;
    padding: 0 0%!important;
}

.footer-info {
    margin-right: 30px;
    line-height: 38.8px;
}

.logo {
    width:100px;
    height: 65px;
    background: no-repeat center url(../../assets/logo.svg);
    position: relative;
}

.site-name {
    line-height: 1.5rem;
    margin-top: 1.8rem;
    margin-right: auto;
    font-size: 16px;
    font-family: Georgia;
}

.site-name:before {
    content: '|';
    padding-right: 1rem;
    display: inline-block;
}

.el-menu-item:hover {
    color: #e0301e!important;
    border-bottom: 2px solid #d04a02!important;
}

.active-show {
    color: #e0301e!important;
    border-bottom: 2px solid #d04a02!important;
}

.navbar {
    margin-right: 30px;
}

.el-menu-item {
    margin-right: 10px!important;
    font-size: 13px!important;
}

.el-dropdown-link .el-avatar:hover {
    cursor: pointer;
}
</style>
