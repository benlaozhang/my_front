import Vue from 'vue'
import Router from 'vue-router'
import p1 from '@/components/pages/page1'

import content from '@/components/widgets/content'
Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'page1',
      component: p1,
    }
  ]
})
